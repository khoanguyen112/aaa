"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _http = _interopRequireDefault(require("http"));

var _express = _interopRequireDefault(require("express"));

var _cors = _interopRequireDefault(require("cors"));

var _morgan = _interopRequireDefault(require("morgan"));

var _bodyParser = _interopRequireDefault(require("body-parser"));

var _middleware = _interopRequireDefault(require("./middleware"));

var _api = _interopRequireDefault(require("./api"));

var _env = _interopRequireDefault(require("./env.json"));

var _cleaner = _interopRequireDefault(require("./lib/cleaner"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let app = (0, _express.default)();
app.server = _http.default.createServer(app); // logger

app.use((0, _morgan.default)('dev')); // 3rd party middleware

app.use((0, _cors.default)({
  exposedHeaders: _env.default.corsHeaders
}));
app.use(_bodyParser.default.json({
  limit: _env.default.bodyLimit
}));
app.use(_bodyParser.default.urlencoded({
  extended: true
})); // internal middleware
// app.use(middleware({ config }));

app.use((0, _middleware.default)()); // api router
// app.use('/api', api({ config }));

app.use('/api', (0, _api.default)());
app.server.listen(_env.default.http, () => {
  console.log(`Started on port ${app.server.address().port}`);
});
(0, _cleaner.default)();
var _default = app;
exports.default = _default;
//# sourceMappingURL=index.js.map