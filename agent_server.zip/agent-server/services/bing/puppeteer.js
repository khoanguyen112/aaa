"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _util = _interopRequireDefault(require("../../lib/util"));

var _websocket = _interopRequireDefault(require("./websocket"));

var _cheerio = _interopRequireDefault(require("cheerio"));

var _puppeteerExtra = _interopRequireDefault(require("puppeteer-extra"));

var _bing = _interopRequireDefault(require("../../config/bing"));

var _puppeteerExtraPluginStealth = _interopRequireDefault(require("puppeteer-extra-plugin-stealth"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @author              609-4
 * @createdby           PYS
 * @since               03-10-2020
 * @version             1.0
 * @description         Starting puppeteer instance & connect to web socket server
 */
// puppeteer-extra is a drop-in replacement for puppeteer,
// it augments the installed puppeteer with plugin functionality
// add stealth plugin and use defaults (all evasion techniques)
_puppeteerExtra.default.use((0, _puppeteerExtraPluginStealth.default)());

class BingPuppeteerService {
  constructor(sessionId, serach_type) {
    this.config = _bing.default;
    this.sessionId = sessionId;
    this.timerSendHintScrappedList = false;
    this.objWSService = new _websocket.default(_bing.default, sessionId, this); // check existing sessionId

    const isSameSessionId = this.isExistSessionId();

    if (isSameSessionId === true) {
      const isWsClient = _websocket.default.clients[sessionId];

      if (!isWsClient) {
        this.createInstance();
      } else {
        console.log('--------------------- exist same session id ----------------------------');
      }
    } else {
      this.createInstance();
    }
  }
  /**
   * check exist session Id
   * @returns         boolean     true: if doesn't exist the sessionId, false: exist one.
   */


  isExistSessionId() {
    if (!BingPuppeteerService.browsers[this.sessionId]) {
      return false;
    } else {
      return true;
    }
  }

  async createInstance() {
    const config = this.config;
    const sessionId = this.sessionId; // create web socket client object

    const objWSService = this.objWSService;
    console.log("::::::::::::::::::START BING BROWSER::::::::::::::::");
    let browserConfig = config.browser;

    const userAgentKey = _util.default.getRandomInt(0, config.userAgentList.length - 1);

    browserConfig.args.push(`--user-agent=${config.userAgentList[userAgentKey]}`, `--window-size=${config.browser.width},${config.browser.height}`); // puppeteer usage as normal

    let browser;

    try {
      // websocket client connects to the server
      objWSService.connect();
      browser = await _puppeteerExtra.default.launch(browserConfig);
      browser.on('disconnected', async () => {
        console.log('+++++++++++++++++++~~~~~~~~~~~~~~~~~~~~++++++++++++++++');

        try {
          await browser.close();
        } catch (e) {}

        this.evtClosedBrowser();
      }); // keep browser instance

      BingPuppeteerService.browsers[sessionId] = browser;
      const pages = await browser.pages();
      const page = pages[0];
      await page.evaluateOnNewDocument(`navigator.mediaDevices.getUserMedia = navigator.webkitGetUserMedia = navigator.mozGetUserMedia = navigator.getUserMedia = webkitRTCPeerConnection = RTCPeerConnection = MediaStreamTrack = undefined;`);
      await page.setRequestInterception(true); // page.on('console', consoleObj => console.log('WEB PAGE console:: ' + consoleObj.text()));

      await page.on('response', async response => {
        const url = response.url();
        const resourceType = response.request().resourceType();
        const ok = response.ok();

        if (ok === true) {
          // console.log(resourceType, '-------', url, '+++++++++');
          if (resourceType === 'document') {
            // console.log('::::::response url :::::::::::', resourceType, url);
            // should take data
            if (url.indexOf('https://www.bing.com/search?q') === 0) {
              // console.log('~~~~~~~~~~~~~~~~~~~loaded finished~~~~~~~~~~~~~~~~~~~~~~');
              // console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
              await objWSService.objPageService.objRecaptchaService.stopScreencast();

              try {
                await page.waitForNavigation({
                  waitUntil: 'domcontentloaded',
                  timeout: 5000
                });
              } catch (e) {}

              await page.bringToFront();
              await objWSService.objPageService.getAllData();
            } else if (_util.default.checkRecaptchaUrls(config['recaptcha-urls'], url) === true) {
              // console.log('------------------------------------------------------------');
              try {
                await page.waitForNavigation({
                  waitUntil: 'domcontentloaded',
                  timeout: 5000
                });
              } catch (e) {}

              objWSService.send('number', 140);
              await objWSService.objPageService.objRecaptchaService.startScreenCast();
            }
          } else if (resourceType === 'xhr' && url.indexOf('https://www.bing.com/AS/Suggestions') === 0) {
            // console.log('---------------------------------------------------------------------------------');
            if (false !== this.timerSendHintScrappedList) {
              clearTimeout(this.timerSendHintScrappedList);
            }

            this.timerSendHintScrappedList = setTimeout(async () => {
              let body = await response.text();
              let jsonHintList = [];

              try {
                const $ = _cheerio.default.load(body);

                $('ul#sa_ul').find('span.sa_tm_text').each((index, item) => {
                  jsonHintList.push($(item).html());
                }); // send hint results

                objWSService.send('json', {
                  type: 102,
                  body: jsonHintList
                });
              } catch (e) {
                console.log(':: bing getting hint result error', e);
              }
            }, 300);
          }
        }
      });
      await page.on('request', async request => {
        const url = request.url();
        const resourceType = request.resourceType();

        if (['font', 'other', 'image'].indexOf(resourceType) > 0) {
          if (resourceType === 'image' && _util.default.checkRecaptchaUrls(config['recaptcha-urls'], url) === true) {
            request.continue();
          } else {
            request.abort();
          }
        } else {
          request.continue();
        }
      });
      await page.on('dialog', async dialog => {
        console.log('~~~~~~~~~~~~~~dialog message content~~~~~~~~~~~~~', dialog.message());
        await dialog.dismiss();
        await browser.close();
      });
      objWSService.setPageObject(page, browser);
      await page.setViewport({
        width: config.browser.width,
        height: config.browser.height
      });

      const xForwaredForIp = _util.default.getRandomIpXforwarded();

      await page.setExtraHTTPHeaders({
        'x-forwarded-for': xForwaredForIp
      });
      await page.goto(config.url, {
        waitUntil: 'domcontentloaded'
      });
      console.log('finished the first loading ..............'); // checking message to translate into english to russia

      try {
        await page.waitForSelector('div#SIvCob', {
          timeout: 500
        });
        const shouldEnglish = await page.evaluate(() => {
          const translatePanel = document.querySelector('div#SIvCob');

          if (translatePanel) {
            const domA = translatePanel.querySelector('a');

            if (domA) {
              domA.click();
              return true;
            }
          }

          return false;
        });

        if (shouldEnglish === true) {
          await page.waitForNavigation({
            waitUntil: 'domcontentloaded'
          });
        }
      } catch (e) {}

      console.log('started the web browser..................');
      objWSService.setPageState();
      objWSService.send('number', 111);
    } catch (baseError) {
      console.log('errorCode 2; browser has been occured base error');
      console.log(baseError);

      try {
        await browser.close();
      } catch (e) {
        console.log('errorCode: 1; browser can not close by self.');
        console.log(e);
      }
    }
  } // events


  evtClosedBrowser() {
    // remove kept puppeteer instance
    delete BingPuppeteerService.browsers[this.sessionId];
    this.objWSService.destorySocketClient();
  }

}

exports.default = BingPuppeteerService;
BingPuppeteerService.browsers = {};
//# sourceMappingURL=puppeteer.js.map