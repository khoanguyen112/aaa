"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _util = _interopRequireDefault(require("../../lib/util"));

var _recaptcha = _interopRequireDefault(require("./recaptcha"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @author              609-4
 * @createdby           KSY
 * @since               02-13-2020
 * @version             1.0
 * @description         web page controller
 */
const inputBoxSelector = 'input[name=q]';
const didYouMeanSelector = 'a.gL9Hy';

class PageService {
  constructor(config, page, browser, wsClient) {
    this.config = config;
    this.page = page;
    this.browser = browser;
    this.wsClient = wsClient;
    this.objRecaptchaService = new _recaptcha.default(page, wsClient);
    this.signalAllowSetImageEventTimer = false;
  }

  async closePage() {
    await this.page.close();

    try {
      await this.browser.close(); // console.log('-------------------------browser closed-----------------------');
    } catch (error) {
      console.log(error);
      await this.browser.close();
    } finally {
      await this.browser.close();
    }
  }

  async runHintEvent(hintText) {
    // console.log('Received from the hint text', hintText);
    try {
      await this.setSearchTextToBox(hintText);
    } catch (e) {
      console.log('page hint event running was occured');
      console.log(e);
    }
  }

  runSearchEvent(searchText) {
    // console.log('Received from the search text', searchText);
    const page = this.page;

    try {
      const searchUrl = `https://www.google.com/search?q=${searchText}`;
      page.goto(searchUrl);
    } catch (e) {
      this.wsClient.send('number', 143);
      console.log('errorCode 10; searching has been failed.');
      console.log(e);
    }
  }

  async runDidYouMean() {
    const page = this.page;
    const isRan = await page.evaluate(didYouMeanSelector => {
      const aLinkDom = document.querySelector(didYouMeanSelector);

      if (aLinkDom) {
        aLinkDom.click();
        return true;
      }

      return false;
    }, didYouMeanSelector); // console.log('Ran did you mean --- ', isRan);

    if (false === isRan) {
      this.wsClient.send('number', 143);
    }
  }

  async runPaginate(pageValue) {
    // console.log('Would go to page number is ', pageValue);
    const page = this.page;

    try {
      await page.evaluate(pageValue => {
        const domPageBox = document.querySelectorAll('[role="navigation"]')[1]; // let pageBox = document.querySelectorAll('[role="navigation"]')[1];  

        if (domPageBox) {
          const hyperLinkDom = domPageBox.querySelector('td:nth-child(' + pageValue + ') > a');

          if (hyperLinkDom) {
            hyperLinkDom.click();
            return true;
          }
        }

        return false;
      }, pageValue);
    } catch (e) {
      this.wsClient.send('number', 143);
      console.log('go to paginate error was occured');
      console.log(e);
    }
  }

  async getCurrentData() {
    const config = this.config;
    const page = this.page;
    const url = page.url();

    if (_util.default.checkRecaptchaUrls(config['recaptcha-urls'], url) === true) {
      this.wsClient.send('number', 140);
      await this.objRecaptchaService.startScreenCast();
    } else {
      // console.log('trying getting current data-------------------');
      try {
        // await page.waitForSelector('div#slim_appbar', { timeout: 100 });
        await page.waitForSelector('div#search', {
          timeout: 100
        }); // console.log('getting retrying all data');

        await this.getAllData();
      } catch (e) {
        await this.getHintList();
      }
    }
  }

  async getAllData() {
    const page = this.page;

    if (!page) {
      console.log('errorCode 11; page is not defined');
      return false;
    } // send the scrapped results


    await this.getSearchedResult(); // send paginate data

    await this.getPaginate(); // send result state

    await this.getResultState(); // send keyboard value

    await this.getResultKeyword(); // send related value

    await this.getRelatedKeywords(); // send search box value

    const searchBoxValue = await page.$eval(inputBoxSelector, el => el.value);
    this.wsClient.send('json', {
      type: 103,
      body: searchBoxValue
    });
    await this.getDidYouMean();
    await this.getHintList();
  }

  async getSearchedResult() {
    // console.log('started: get searched result...');
    const page = this.page;
    let searchedResult = [];

    try {
      //await page.waitForSelector('div#slim_appbar', {
      await page.waitForSelector('div#search', {
        timeout: 3000
      });
      searchedResult = await page.evaluate(() => {
        // const domItems = document.querySelectorAll('div.srg div.g div.rc');
        const domItems = document.querySelectorAll('div.g'); // const domItems = document.querySelectorAll('div#');

        let resultItems = [];
        let resultItem = {};
        const checkRegexp = /[\uac00-\ud7af]|[\u1100-\u11ff]|[\u3130-\u318f]|[\ua960-\ua97f]|[\ud7b0-\ud7ff]/ugi;
        domItems.forEach(item => {
          const domContentSpan = item.querySelector('div.VwiC3b');
          const dom_title_h3_a = item.querySelector('div.yuRUbf > a');

          if (domContentSpan && dom_title_h3_a) {
            const h = dom_title_h3_a.getAttribute('href');
            const t = dom_title_h3_a.querySelector('h3.LC20lb').innerHTML;
            const c = domContentSpan.innerHTML;

            if (checkRegexp.test(h) || checkRegexp.test(t) || checkRegexp.test(c)) {
              return;
            }

            resultItem = {
              /*href = real url*/
              h: h,

              /*title*/
              t: t,

              /*content*/
              c: c
            }; // filePrev

            const filePrevItem = item.querySelector('span.ZGwO7');

            if (filePrevItem) {
              resultItem.f = filePrevItem.innerHTML;
            }

            resultItems.push(resultItem);
          }
        });
        return resultItems;
      }); // console.log('end: get searched result...');
    } catch (e) {
      console.log('errorCode 15; taking searched result failed');
      console.log(e);
    }

    this.wsClient.send('json', {
      type: 104,
      body: searchedResult
    });
  }

  async getPaginate() {
    const page = this.page;
    const pageData = await page.evaluate(() => {
      let pageBox = document.querySelectorAll('[role="navigation"]')[1];

      if (pageBox) {
        var result = [];
        Array.from(pageBox.querySelectorAll('td')).forEach(function (td_item, index) {
          var page_item_data = {
            txt: td_item.innerText.trim()
          };

          if ('SPAN' === td_item.children[0].nodeName) {
            page_item_data.cur = true;
          } else if (td_item.getAttribute('role') == 'heading') {
            if (index == 0) {
              page_item_data.fst = true;
            } else {
              page_item_data.lst = true;
            }
          }

          result.push(page_item_data);
        });
        return result;
      } else return false;
    });
    this.wsClient.send('json', {
      type: 105,
      body: pageData
    });
  }

  async setSearchTextToBox(text) {
    // console.log('started set input box value .....');
    const page = this.page;
    const isExistElement = await page.$eval(inputBoxSelector, el => el ? true : false); // console.log('var: isExistElement is', isExistElement)

    if (isExistElement) {
      const hintTypeDelayTimes = [50, 60, 70, 40, 90, 120];

      const hintDelayTimeArrIndex = _util.default.getRandomInt(0, hintTypeDelayTimes.length - 1);

      const hintDelayTime = hintTypeDelayTimes[hintDelayTimeArrIndex];
      await page.focus(inputBoxSelector);
      await page.$eval(inputBoxSelector, el => el.setSelectionRange(0, el.value.length));
      await page.keyboard.press('Backspace');
      await page.waitFor(100);
      await page.type(inputBoxSelector, text, {
        delay: hintDelayTime
      }); // console.log('finished setting value .....');
    }
  }

  async getResultKeyword() {
    const page = this.page;
    const pageKeywordData = await page.evaluate(() => {
      var resultKeyword = document.querySelector('span.gL9Hy');
      var resultKeywordValue = document.querySelector('div.med > p.card-section > a');
      if (!resultKeyword || !resultKeywordValue) return false;
      return resultKeyword.innerHTML + ' ' + resultKeywordValue.innerHTML;
    }); // console.log('wwwwww==================' + pageKeywordData);

    this.wsClient.send('json', {
      type: 108,
      body: pageKeywordData
    });
  }

  async getRelatedKeywords() {
    const page = this.page;
    const relatedKeywordData = await page.evaluate(() => {
      var domRelatedKeywords = document.querySelector('div#brs div.card-section');
      if (!domRelatedKeywords) return false;
      var items = domRelatedKeywords.querySelectorAll('a');
      var length = items.length,
          i = 0;

      if (length > 0) {
        for (; i < length; i++) {
          items[i].removeAttribute('href');
        }
      }

      return domRelatedKeywords.innerHTML;
    });
    this.wsClient.send('json', {
      type: 109,
      body: relatedKeywordData
    });
  }

  async getResultState() {
    const page = this.page;
    const pageStateData = await page.evaluate(() => {
      var resultStateBox = document.querySelector('div#result-stats');
      if (!resultStateBox) return false;
      return resultStateBox.innerHTML;
    });
    this.wsClient.send('json', {
      type: 106,
      body: pageStateData
    });
  }

  async getHintList() {
    const page = this.page;

    if (!page) {
      console.log('errorCode 11; page is not defined');
      return false;
    }

    const containerHintListSelector = 'div[jscontroller="J7ZZy"]';
    await page.waitFor(1000);
    await page.waitForSelector(containerHintListSelector, {
      timeout: 10000
    });
    const scrappedHintList = await page.evaluate(() => {
      const containerHintListSelector = 'div[jscontroller="J7ZZy"]';
      const hintSelector = 'li.sbct:not([id]) div.sbtc > div';
      const hintDomItems = document.querySelector(containerHintListSelector).querySelectorAll(hintSelector);
      let scrappedHtmlItems = [];

      if (hintDomItems && hintDomItems.length > 0) {
        hintDomItems.forEach(item => {
          scrappedHtmlItems.push(item.innerHTML);
        });
      }

      return scrappedHtmlItems;
    }); // console.log('get hint result list', scrappedHintList);
    // send hint results

    this.wsClient.send('json', {
      type: 102,
      body: scrappedHintList
    });
  }

  async getDidYouMean() {
    const page = this.page;
    let didYouMeanVal;

    try {
      await page.waitForSelector(didYouMeanSelector, {
        timeout: 1000
      });
      didYouMeanVal = await page.$eval(didYouMeanSelector, el => el.innerHTML);
    } catch (e) {
      didYouMeanVal = '';
    }

    this.wsClient.send('json', {
      type: 111,
      body: didYouMeanVal
    });
  }

  async applyClickEvent(body) {
    const {
      left,
      top
    } = body;
    const page = this.page;
    const url = page.url();
    const config = this.config; // console.log('current url =-------=', url)

    if (false === _util.default.checkRecaptchaUrls(config['recaptcha-urls'], url)) {
      console.log('Must just be closed because of violation url');

      try {
        console.log('Browser has been closed by user because user went to violation interet address!');
        await this.browser.close();
      } catch (e) {}

      return;
    }

    let {
      width,
      height
    } = await page.evaluate(() => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      return {
        width,
        height
      };
    }); // width = 500;
    // height = 568;
    // calculate coordnates

    let browserLeft = 0;
    if (left) browserLeft = width * left;
    let browserTop = 0;
    if (top) browserTop = height * top;
    await page.mouse.click(browserLeft, browserTop, {
      button: 'left'
    }); // set signal ..... for allow set image event -

    if (this.signalAllowSetImageEventTimer !== false) {
      clearTimeout(this.signalAllowSetImageEventTimer);
    }

    this.signalAllowSetImageEventTimer = setTimeout(() => {
      this.signalAllowSetImageEventTimer = false;
      this.wsClient.send('number', 141);
    }, 1000);
  }

}

exports.default = PageService;
//# sourceMappingURL=page.js.map