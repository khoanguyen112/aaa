"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _ws = _interopRequireDefault(require("ws"));

var _page = _interopRequireDefault(require("./page"));

var _puppeteer = _interopRequireDefault(require("./puppeteer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @author              609-4
 * @createdby           KSY
 * @since               02-11-2020
 * @version             1.0
 * @description         Web socket client module for puppeteer instance
 */
class WebSocketClient {
  // key and value pair for keeping client socket handlers
  // [sessionId] = handler Object
  constructor(config, sessionId, puppteerService) {
    // this is web socket server url
    this.puppteerService = puppteerService;
    this.config = config;
    this.url = config.websocket;
    this.sessionId = sessionId;
    this.objPageService = null;
    this.loadedPage = false;
    this.autoCloseBrowserTimer = false;
    this.reconnectTimer = false;
    this.reconnectMaxCount = 15;
    this.reconnectCount = 0;
    this.forceClose = false;
  }

  connect() {
    const wsUrl = this.url + this.sessionId + '/' + 'google'; // console.log(`------------------ trying to connect to the ws server(${wsUrl})...`);

    let handler = new _ws.default(wsUrl);
    const sessionId = this.sessionId;
    handler.on('open', () => {
      if (this.reconnectTimer !== false) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = false;
        this.reconnectCount = 0;
      } // console.log('ws client has been connected to server');


      WebSocketClient.clients[sessionId] = handler;
    });
    handler.on('message', data => {
      // console.log('------------------- received: message from the server');
      // console.log(data);
      this.controlPage(data);
    });
    handler.on('error', () => {
      console.log('errorCode 3; web socket client has been disconnected');
    });
    handler.on('close', (code, reason) => {
      const forceClose = this.forceClose;
      console.log('::::is force closing -----', forceClose);

      if (forceClose) {
        return false;
      } // console.log('web socket client has been closed.');


      console.log(reason);
      this.reconnect();
    });
  }

  reconnect() {
    const sessionId = this.sessionId;

    if (this.reconnectTimer !== false) {
      clearTimeout(this.reconnectTimer);
    }

    this.reconnectTimer = setTimeout(() => {
      this.reconnectCount++;

      if (this.reconnectCount > this.reconnectMaxCount) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = false;
        this.reconnectCount = 0; // close chromium

        try {
          _puppeteer.default.browsers[sessionId].close();
        } catch (e) {
          console.log('didnt connect to socket server and browser closing error was occured.');
        }

        return false;
      }

      this.connect();
    }, 1000);
  }

  async send(dataType, _msgData) {
    // console.log('::: socket clients :::', Object.keys(WebSocketClient.clients));
    const sessionId = this.sessionId;
    let msgData = '';

    try {
      if (dataType === 'json') {
        msgData = JSON.stringify(_msgData);
      } else {
        msgData = _msgData;
      }

      this._send(msgData);
    } catch (e) {
      console.log(e);

      try {
        await _puppeteer.default.browsers[sessionId].close();
      } catch (e) {
        this.send('number', 142);
      }
    }
  }

  _send(msgData) {
    const sessionId = this.sessionId;
    const handler = WebSocketClient.clients[sessionId];

    if (handler) {
      // console.log(':::sending data:::', msgData, typeof(msgData))
      try {
        handler.send(msgData);
      } catch (e) {
        console.log('errorCode 5; it can not be sent data to the socket server');
        console.log(e);
        throw 'ERR_DATA_SEND_TO_SERVER';
      }
    } else {
      console.log('errorCode 4; it can not be taken web socket client');
      throw 'ERR_NOT_EXISTS_WEBSOCKET_CLIENT';
    }
  }

  setPageObject(page, browser) {
    this.objPageService = new _page.default(this.config, page, browser, this);
  }

  setPageState() {
    this.loadedPage = true;
  }

  autoCloseBrowser() {
    if (this.autoCloseBrowserTimer !== false) {
      return false;
    }

    this.autoCloseBrowserTimer = setTimeout(async () => {
      if (this.objPageService) {
        // console.log("ssssssssssssssssssssssssssssssssssssssssssssss");
        await this.objPageService.closePage();
      }
    }, 5000);
  }

  async controlPage(data) {
    const sessionId = this.sessionId;

    if (data == '100') {
      this.autoCloseBrowser();
    } else if (data == '101') {
      // console.log('eject setting auto close browser timer');
      if (this.loadedPage === true) {
        this.send('number', 111);
        this.objPageService.getCurrentData();
      }

      if (this.autoCloseBrowserTimer !== false) {
        clearTimeout(this.autoCloseBrowserTimer);
        this.autoCloseBrowserTimer = false;
      }
    } else if (data == '102') {
      // close chromium
      try {
        await _puppeteer.default.browsers[sessionId].close();
        setTimeout(() => {
          new _puppeteer.default(this.config, this.sessionId);
        }, 1000);
      } catch (e) {
        this.send('number', 142);
      }
    } else {
      if (this.objPageService === null) {
        console.log("Sry! puppeteer browser page didn't exist");
        this.destorySocketClient();
        return false;
      }

      try {
        const jsonData = JSON.parse(data);

        if (jsonData.type == '122') {
          this.objPageService.runHintEvent(jsonData.body);
        } else if (jsonData.type == '123') {
          this.objPageService.runSearchEvent(jsonData.body);
        } else if (jsonData.type == '125') {
          this.objPageService.runPaginate(jsonData.body);
        } else if (jsonData.type == '126') {
          this.objPageService.runDidYouMean();
        } else if (jsonData.type == '150') {
          this.objPageService.applyClickEvent(jsonData.body);
        }
      } catch (e) {}
    }
  }

  close() {}

  destorySocketClient() {
    const sessionId = this.sessionId;
    this.forceClose = true;
    console.log('Sry. web socket client will automatically close.');

    try {
      WebSocketClient.clients[sessionId].close();
    } catch (e) {
      console.log('::::websocket closing error');
      console.log(e);
    }

    delete WebSocketClient.clients[sessionId];
  }

}

WebSocketClient.clients = {};
var _default = WebSocketClient;
exports.default = _default;
//# sourceMappingURL=websocket.js.map