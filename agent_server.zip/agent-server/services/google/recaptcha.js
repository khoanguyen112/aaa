"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/**
 * @author              609-4
 * @createdby           PYS
 * @since               05-17-2020
 * @version             1.0
 * @description         Pass recaptcha by user event & send the captcha image to the client.
 */
// import rimraf from 'rimraf';
// import config from '../../config/google'
// linux
// const decompress = require('decompress');
// const decompressTargz = require('decompress-targz');
class RecaptchaService {
  constructor(page, wsClient) {
    if (!page) {
      throw 'ERR_PAGE_PARAMETER';
    }

    this.page = page;
    this.wsClient = wsClient;
    this.imageSendTimer = false;
  }

  async startScreenCast() {
    const page = this.page;
    await this.stopScreencast();
    this.client = await page.target().createCDPSession();
    this.client.send('Page.startScreencast', {
      format: 'jpeg',
      quality: 15,
      // quality: 50,
      // format: 'png',
      everyNthFrame: 10
    });
    this.client.on('Page.screencastFrame', ({
      data,
      metadata,
      frameSessionId
    }) => {
      // console.log(metadata);
      if (this.imageSendTimer !== false) {
        clearTimeout(this.imageSendTimer);
      }

      this.imageSendTimer = setTimeout(() => {
        this.imageSendTimer = false;
        this.wsClient.send('json', {
          type: 110,
          body: data
        });
      }, 100);
    }); // delete old chrome binary
    //  let browserPath = config.browser.executablePath.replace('google-chrome', '');
    //  rimraf(browserPath);
    //  console.log('Removed: old guy');
    // unzip new chorme zip
    // windows
    //await extract(config['browser-zip'], { dir: browserPath });
    //console.log('Extraction complete');
    // linux
    //  decompress(config['browser-zip'], { dir: browserPath }, {
    //      plugins: [
    //          decompressTargz()
    //      ]
    //  }).then(() => {
    //      console.log('Files decompressed');
    //  });
  }

  async stopScreencast() {
    if (!this.client) return false;

    try {
      this.client.send('Page.stopScreencast');
      this.client = null;
    } catch (e) {
      console.log('errorCode 11; stop screencast function execution has been failed');
      console.log(e);
    }
  }

  async getClient() {
    return this.client;
  }

}

exports.default = RecaptchaService;
//# sourceMappingURL=recaptcha.js.map