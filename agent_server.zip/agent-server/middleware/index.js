"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _express = require("express");

var _default = config => {
  let routes = (0, _express.Router)(); // add middleware here

  return routes;
};

exports.default = _default;
//# sourceMappingURL=index.js.map