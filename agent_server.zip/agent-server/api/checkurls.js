"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _isReachable = _interopRequireDefault(require("is-reachable"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = async (config, req, res) => {
  try {
    const body = req.body;
    let aliveUrls = [];
    let i = '';
    let url = '';

    for (i in body) {
      url = body[i];
      console.log('checking url if one is able or not ...', url);
      const isAliveUrl = await (0, _isReachable.default)(url);
      console.log('available status is ', isAliveUrl);

      if (true === isAliveUrl) {
        aliveUrls.push(url);
      }
    }

    res.json(aliveUrls);
  } catch (e) {
    console.log(`checkurls. request params is incorrect.`);
    console.log(e);
    res.send('errorCode 16; checking urls request params have been failed');
  }

  ;
};

exports.default = _default;
//# sourceMappingURL=checkurls.js.map