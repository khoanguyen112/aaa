"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _package = require("../../package.json");

var _express = require("express");

var _agent = _interopRequireDefault(require("./agent"));

var _checkurls = _interopRequireDefault(require("./checkurls"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = () => {
  let api = (0, _express.Router)(); // mount the agent resource

  api.post('/agent', (req, res) => {
    (0, _agent.default)(req, res);
  });
  api.post('/checkurls', (req, res) => {
    (0, _checkurls.default)(req, res);
  }); // perhaps expose some API metadata at the root

  api.get('/', (req, res) => {
    res.json({
      version: _package.version
    });
  });
  return api;
};

exports.default = _default;
//# sourceMappingURL=index.js.map