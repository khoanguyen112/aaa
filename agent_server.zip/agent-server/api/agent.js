"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _puppeteer = _interopRequireDefault(require("../services/google/puppeteer"));

var _puppeteer2 = _interopRequireDefault(require("../services/baidu/puppeteer"));

var _puppeteer3 = _interopRequireDefault(require("../services/bing/puppeteer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = (req, res) => {
  try {
    const sessionId = req.body.sessionId;
    const search_type = req.body.search_type; // console.log('config==========', config);

    console.log(`Received session id ${sessionId}`);
    console.log('Params::::::::', req.body);
    console.log(`Thanks, Server has received the serach type as ${search_type}`);

    switch (search_type) {
      //switch start
      case 'google':
        new _puppeteer.default(sessionId, search_type);
        break;

      case 'baidu':
        new _puppeteer2.default(sessionId, search_type);
        break;

      case 'bing':
        new _puppeteer3.default(sessionId, search_type);
        break;
    }

    ; //switch end

    res.send('ok');
  } catch (e) {
    console.log(`Sry! request params is incorrect.`);
    console.log(e);
    res.send('errorCode 6; request params have been failed');
  }

  ;
};

exports.default = _default;
//# sourceMappingURL=agent.js.map